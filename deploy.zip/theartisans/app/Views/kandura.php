<div class="container px-lg-5 py-5">
	<div class="row">
    <div class="col-lg-12">
      <img src="<?php echo base_url('images/kandura/image-3.png'); ?>" class="img-fluid">
    </div>
  </div>
  <div class="row">
		<div class="col-lg-8 py-5 mx-auto">
			<h1 class="headline">
				Emirati Kandura Tailoring
			</h1>
      <div class="d-grid gap-2">
        <a class="btn btn-dark btn-lg rounded-0" href="tel:+97145844777">Book Now</a>
      </div>
		</div>
	</div>
  <div class="row">
    <div class="col-lg-6 mb-lg-0 mb-3">
      <img src="<?php echo base_url('images/kandura/image-1.png'); ?>" class="img-fluid">
    </div>
  </div>
</div>


	