<div class="container px-lg-5 py-5">
	<div class="row">
    <div class="col-lg-12">
      <img src="<?php echo base_url('images/bespoke/image-3.png'); ?>" class="img-fluid">
    </div>
  </div>
  <div class="row">
		<div class="col-lg-8 py-5 mx-auto">
			<h1 class="headline">
				Luxury Suiting
			</h1>
		</div>
	</div>
  <div class="row reveal">
    <div class="col-lg-6 mb-lg-0 mb-3">
      <img src="<?php echo base_url('images/uniforms/image-1.png'); ?>" class="img-fluid">
    </div>
  </div>
</div>


	