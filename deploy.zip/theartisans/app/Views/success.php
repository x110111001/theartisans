<div class="container px-lg-5 py-3 d-lg-block d-none">
	<div class="row">
		<div class="col-lg-12 mx-auto py-5">
			<h1 class="fw-bold">Thank you for subscribing to our newsletter!</h1>
			<p>
				You'll get the latest on products, styling and events.
			</p>
		</div>
	</div>
</div>